package com.example.project.filmapp.utils

enum class DataState {
    LOADING, SUCCESS, ERROR
}